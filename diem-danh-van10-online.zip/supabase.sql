-- SUPABASE SQL: chạy toàn bộ đoạn này trong SQL Editor
create extension if not exists pgcrypto;

create table if not exists public.students (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  position integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.attendance (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  attendance_date date not null,
  status text not null check (status in ('present','absent','late')),
  updated_at timestamptz not null default now(),
  unique(student_id, attendance_date)
);

alter table public.students enable row level security;
alter table public.attendance enable row level security;

drop policy if exists "public read students" on public.students;
create policy "public read students" on public.students for select to anon using (true);

drop policy if exists "public insert students" on public.students;
create policy "public insert students" on public.students for insert to anon with check (true);

drop policy if exists "public update students" on public.students;
create policy "public update students" on public.students for update to anon using (true) with check (true);

drop policy if exists "public delete students" on public.students;
create policy "public delete students" on public.students for delete to anon using (true);

drop policy if exists "public read attendance" on public.attendance;
create policy "public read attendance" on public.attendance for select to anon using (true);

drop policy if exists "public insert attendance" on public.attendance;
create policy "public insert attendance" on public.attendance for insert to anon with check (true);

drop policy if exists "public update attendance" on public.attendance;
create policy "public update attendance" on public.attendance for update to anon using (true) with check (true);

drop policy if exists "public delete attendance" on public.attendance;
create policy "public delete attendance" on public.attendance for delete to anon using (true);

alter table public.students replica identity full;
alter table public.attendance replica identity full;

-- Sau khi tạo bảng, vào Database > Replication và bật realtime cho:
-- public.students
-- public.attendance
