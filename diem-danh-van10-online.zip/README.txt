# Điểm Danh • Học Sinh Giỏi Văn 10

## Cách đưa web online miễn phí

### 1. Tạo Supabase
- Vào https://supabase.com/
- Tạo tài khoản và New project.
- Mở SQL Editor.
- Dán toàn bộ nội dung `supabase.sql` rồi Run.
- Vào Project Settings > API.
- Lấy `Project URL` và `anon public key`.

### 2. Nối web với Supabase
Mở `index.html`, tìm:
const SUPABASE_URL = "DAN_SUPABASE_URL_VAO_DAY";
const SUPABASE_ANON_KEY = "DAN_SUPABASE_ANON_KEY_VAO_DAY";

Thay bằng URL và anon public key của project.

### 3. Đưa lên GitHub Pages
- Tạo repository mới trên GitHub.
- Upload `index.html`.
- Settings > Pages > Deploy from branch > chọn main / root.
- GitHub sẽ cấp link `https://ten-tai-khoan.github.io/ten-repo/`.

## Lưu ý quan trọng
Bản này là mô hình "ai có link cũng có quyền sửa dữ liệu". Phù hợp cho lớp nhỏ dùng chung, nhưng nếu muốn chỉ giáo viên được thêm/xóa học sinh còn học sinh chỉ được tích điểm danh, cần thêm đăng nhập/phân quyền trước khi dùng rộng rãi.
